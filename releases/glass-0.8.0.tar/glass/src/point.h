/*******************************************************************************
 * Description:
 *   TBD
 ******************************************************************************/

#ifndef _POINT_H_
#define _POINT_H_

#include <stdio.h>

class Point {

public:
    int x;
    int y;

public:
    bool zero();
    
};

#endif