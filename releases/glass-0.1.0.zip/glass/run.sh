#/bin/sh
reset;make && gdb glass
