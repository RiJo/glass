/*
 * aewm++ - A small C++ window manager developed from aewm 0.9.6 around 2000 
 *
 * Frank Hale
 * frankhale@gmail.com
 *
 * http://code.google.com/p/aewmpp/
 * 
 * Date: 28 December 2008
 *
 * This code is released under the GPL license www.gnu.org
 *
 * See LICENSE.txt which is included with the source code files.
 */

#ifndef _WINDOWMENU_H_
#define _WINDOWMENU_H_

#include "aewm.h"

class WindowMenu : public GenericMenu
{
private:
	Client *client;
	
public:
	WindowMenu(Display * dpy);

	virtual void handleButtonReleaseEvent(XButtonEvent *e);

	void updateWindowMenu();
	
	void setThisClient(Client *c) { client = c; }
};

#endif 
