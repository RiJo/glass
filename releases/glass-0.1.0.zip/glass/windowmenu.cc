/*
 * aewm++ - A small C++ window manager developed from aewm 0.9.6 around 2000 
 *
 * Frank Hale
 * frankhale@gmail.com
 *
 * http://code.google.com/p/aewmpp/
 * 
 * Date: 28 December 2008
 *
 * This code is released under the GPL license www.gnu.org
 *
 * See LICENSE.txt which is included with the source code files.
 */

#include "aewm.h"

WindowMenu::WindowMenu(Display * dpy) : GenericMenu(dpy)
{
	updateWindowMenu();
}

void WindowMenu::updateWindowMenu()
{
	char* temp = new char[wm->getMaxDesktops()];
	for(int i=0; i<wm->getMaxDesktops(); i++)
	{
		sprintf(temp, "%d", i);
		
		insert(temp,"", SEND_TO_DESKTOP);
	}		
	delete [] temp;

	updateMenu();
	
	addToMenuList(this);
}

void WindowMenu::handleButtonReleaseEvent(XButtonEvent *e)
{
	int desktop=0;
	
	GenericMenu::handleButtonReleaseEvent(e);

	switch (e->button) 
	{
		case Button1:
			if (curr) 
			{
				switch(	curr->function )
				{
					case SEND_TO_DESKTOP:
						desktop = atoi(curr->name.c_str());
						if(client) client->setDesktop(desktop);
						hideAllVisibleSubmenus();
					break;
				
				}										
			}	
		break;
	} 
}
