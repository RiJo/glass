/*
 * aewm++ - A small C++ window manager developed from aewm 0.9.6 around 2000 
 *
 * Frank Hale
 * frankhale@gmail.com
 *
 * http://code.google.com/p/aewmpp/
 * 
 * Date: 28 December 2008
 *
 * This code is released under the GPL license www.gnu.org
 *
 * See LICENSE.txt which is included with the source code files.
 */

#ifndef _ICONMENU_H_
#define _ICONMENU_H_

#include "aewm.h"

class IconMenu : public GenericMenu
{
private:
    Client *client;

public:
    IconMenu(Display * dpy);

    virtual void handleButtonReleaseEvent(XButtonEvent *e);

    void setThisClient(Client *c) { client = c; }

    void addThisClient(Client *c);
    void removeClientFromIconMenu(Client *c);
    void updateClientName(Client *c);
};

#endif
