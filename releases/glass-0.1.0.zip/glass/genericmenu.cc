/*
 * aewm++ - A small C++ window manager developed from aewm 0.9.6 around 2000
 *
 * Frank Hale
 * frankhale@gmail.com
 *
 * http://code.google.com/p/aewmpp/
 *
 * Date: 28 December 2008
 *
 * This code is released under the GPL license www.gnu.org
 *
 * See LICENSE.txt which is included with the source code files.
 */

#include "aewm.h"

GenericMenu::GenericMenu(Display * dpy) : BaseMenu(dpy)
{
}

GenericMenu::~GenericMenu()
{
    menuList.clear();
}

BaseMenu* GenericMenu::findMenu(Window w)
{
    if (w && w != DefaultRootWindow(dpy)) {
        if(menuList.size())
        {
            list<BaseMenu*>::iterator menu_it;

            for(menu_it = menuList.begin(); menu_it != menuList.end(); menu_it++)
            {
                if (w == (*menu_it)->getMenuWindow())
                {
                    return (*menu_it);
                }
            }
        }
    }

    return NULL;
}
